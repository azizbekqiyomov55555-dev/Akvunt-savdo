import sqlite3
import os

DB_PATH = "bot_database.db"


class Database:
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_tables()

    def _create_tables(self):
        c = self.conn.cursor()
        c.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                username TEXT,
                full_name TEXT,
                created_at TEXT DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS uc_prices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                amount INTEGER NOT NULL,
                price INTEGER NOT NULL,
                created_at TEXT DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS card (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                number TEXT NOT NULL,
                owner TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                uc_id INTEGER NOT NULL,
                uc_amount INTEGER NOT NULL,
                price INTEGER NOT NULL,
                pubg_photo TEXT,
                check_photo TEXT,
                status TEXT DEFAULT 'pending',
                created_at TEXT
            );
        """)
        self.conn.commit()

    # ── Users ──
    def add_user(self, user_id: int, username: str, full_name: str):
        c = self.conn.cursor()
        c.execute(
            "INSERT OR IGNORE INTO users (id, username, full_name) VALUES (?, ?, ?)",
            (user_id, username, full_name)
        )
        self.conn.commit()

    # ── UC Prices ──
    def get_uc_list(self):
        c = self.conn.cursor()
        return [dict(r) for r in c.execute("SELECT * FROM uc_prices ORDER BY amount ASC").fetchall()]

    def get_uc_by_id(self, uc_id: int):
        c = self.conn.cursor()
        row = c.execute("SELECT * FROM uc_prices WHERE id=?", (uc_id,)).fetchone()
        return dict(row) if row else None

    def add_uc(self, amount: int, price: int):
        c = self.conn.cursor()
        c.execute("INSERT INTO uc_prices (amount, price) VALUES (?, ?)", (amount, price))
        self.conn.commit()

    def delete_uc(self, uc_id: int):
        c = self.conn.cursor()
        c.execute("DELETE FROM uc_prices WHERE id=?", (uc_id,))
        self.conn.commit()

    # ── Card ──
    def get_card(self):
        c = self.conn.cursor()
        row = c.execute("SELECT * FROM card ORDER BY id DESC LIMIT 1").fetchone()
        return dict(row) if row else None

    def set_card(self, number: str, owner: str):
        c = self.conn.cursor()
        c.execute("DELETE FROM card")
        c.execute("INSERT INTO card (number, owner) VALUES (?, ?)", (number, owner))
        self.conn.commit()

    # ── Orders ──
    def create_order(self, user_id, uc_id, uc_amount, price, pubg_photo, check_photo, created_at):
        c = self.conn.cursor()
        c.execute(
            """INSERT INTO orders
               (user_id, uc_id, uc_amount, price, pubg_photo, check_photo, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (user_id, uc_id, uc_amount, price, pubg_photo, check_photo, created_at)
        )
        self.conn.commit()
        return c.lastrowid

    def get_order(self, order_id: int):
        c = self.conn.cursor()
        row = c.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
        return dict(row) if row else None

    def update_order_status(self, order_id: int, status: str):
        c = self.conn.cursor()
        c.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
        self.conn.commit()

    def get_user_orders(self, user_id: int, limit: int = 5):
        c = self.conn.cursor()
        rows = c.execute(
            "SELECT * FROM orders WHERE user_id=? ORDER BY id DESC LIMIT ?",
            (user_id, limit)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_recent_orders(self, limit: int = 10):
        c = self.conn.cursor()
        rows = c.execute(
            "SELECT * FROM orders ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_stats(self):
        c = self.conn.cursor()
        users = c.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        total = c.execute("SELECT COUNT(*) FROM orders").fetchone()[0]
        approved = c.execute("SELECT COUNT(*) FROM orders WHERE status='approved'").fetchone()[0]
        rejected = c.execute("SELECT COUNT(*) FROM orders WHERE status='rejected'").fetchone()[0]
        pending = c.execute("SELECT COUNT(*) FROM orders WHERE status='pending'").fetchone()[0]
        total_sum = c.execute("SELECT COALESCE(SUM(price),0) FROM orders WHERE status='approved'").fetchone()[0]
        return {
            "users": users,
            "total_orders": total,
            "approved": approved,
            "rejected": rejected,
            "pending": pending,
            "total_sum": total_sum,
        }


db = Database()
