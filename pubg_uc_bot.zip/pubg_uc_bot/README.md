# 🎮 PUBG UC Bot — O'rnatish va ishga tushirish

## 📁 Fayllar
```
pubg_uc_bot/
├── bot.py          ← Asosiy bot kodi
├── database.py     ← Ma'lumotlar bazasi
├── config.py       ← TOKEN va ADMIN ID sozlamalari
├── requirements.txt
└── README.md
```

---

## ⚙️ O'rnatish

### 1. Python o'rnating (3.10+)
https://python.org/downloads

### 2. Kutubxonalarni o'rnating
```bash
pip install -r requirements.txt
```

### 3. config.py ni tahrirlang
```python
BOT_TOKEN = "bu yerga BotFather tokenini kiriting"
ADMIN_IDS = [sizning_telegram_id]
```

> ID ni bilish: @userinfobot ga `/start` yuboring

### 4. Botni ishga tushiring
```bash
python bot.py
```

---

## 🤖 Bot funksiyalari

### Foydalanuvchi uchun:
| Tugma | Vazifa |
|-------|--------|
| 🎮 PUBG MOBILE UC OLISH | UC sotib olish jarayonini boshlash |
| 📋 Mening buyurtmalarim | Oxirgi 5 buyurtmani ko'rish |
| 🆘 Yordam | Yo'riqnoma |

### UC sotib olish jarayoni:
1. UC miqdorini tanlash (chap/o'ng tugmalar)
2. PUBG ID ko'rsatilgan ekran rasmini yuborish
3. Karta raqami va summa ko'rsatiladi
4. To'lov qilib, chek rasmini yuborish
5. Admin tasdiqlaydi → foydalanuvchiga xabar keladi

---

## 🛠 Admin Panel

`/admin` buyrug'ini yuboring yoki admin menyusiga kiring.

| Menyu | Vazifa |
|-------|--------|
| 💰 UC narxlarini boshqarish | UC qo'shish, o'chirish |
| 💳 Karta raqamini sozlash | To'lov kartasini yangilash |
| 📦 Buyurtmalar | So'nggi buyurtmalarni ko'rish |
| 📊 Statistika | Umumiy hisobot |

### Karta kiritish formati:
```
8600 0000 0000 0000
Ism Familiya
```
(Birinchi qatorda karta, ikkinchida egasi)

### Buyurtma kelganda admin:
- PUBG ID rasmi keladi
- Chek rasmi + barcha ma'lumotlar keladi
- **✅ Tasdiqlash** yoki **❌ Rad etish** tugmasi bor
- Foydalanuvchiga avtomatik xabar ketadi

---

## 📊 Ma'lumotlar bazasi
`bot_database.db` fayli avtomatik yaratiladi (SQLite).

---

## 🕐 Vaqt
Barcha vaqtlar **Toshkent vaqti** (UTC+5) bilan ko'rsatiladi.
