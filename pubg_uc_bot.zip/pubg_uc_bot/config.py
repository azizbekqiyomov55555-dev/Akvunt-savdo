# ══════════════════════════════════════════
#  SOZLAMALAR — bu yerga o'z ma'lumotlaringizni kiriting
# ══════════════════════════════════════════

# BotFather dan olgan token
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"

# Admin Telegram ID raqamlari (bir nechta bo'lishi mumkin)
# ID ni bilish uchun @userinfobot ga /start yozing
ADMIN_IDS = [
    123456789,   # ← o'z ID raqamingizni yozing
    # 987654321, # ← ikkinchi admin (ixtiyoriy)
]
