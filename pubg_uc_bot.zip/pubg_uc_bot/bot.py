import logging
import os
from datetime import datetime
import pytz
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    ReplyKeyboardMarkup, KeyboardButton, InputMediaPhoto
)
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, ConversationHandler, filters
)
from config import BOT_TOKEN, ADMIN_IDS
from database import db

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

TASHKENT_TZ = pytz.timezone("Asia/Tashkent")

# ──── CONVERSATION STATES ────
(
    UC_SELECT, PUBG_ID_PHOTO, CHECK_PHOTO,
    ADMIN_ADD_UC_AMOUNT, ADMIN_ADD_UC_PRICE,
    ADMIN_ADD_CARD,
    ADMIN_EDIT_UC_AMOUNT, ADMIN_EDIT_UC_PRICE,
) = range(8)


# ═══════════════════════════════════════════════
#  HELPERS
# ═══════════════════════════════════════════════

def tashkent_now() -> str:
    now = datetime.now(TASHKENT_TZ)
    return now.strftime("%d.%m.%Y %H:%M:%S")


def main_menu_keyboard():
    keyboard = [
        [KeyboardButton("🎮 PUBG MOBILE UC OLISH")],
        [KeyboardButton("📋 Mening buyurtmalarim"), KeyboardButton("🆘 Yordam")],
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


def admin_menu_keyboard():
    keyboard = [
        [KeyboardButton("💰 UC narxlarini boshqarish")],
        [KeyboardButton("💳 Karta raqamini sozlash")],
        [KeyboardButton("📦 Buyurtmalar")],
        [KeyboardButton("📊 Statistika")],
        [KeyboardButton("🔙 Asosiy menyu")],
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)


def uc_list_keyboard(page: int = 0):
    """UC narxlarini inline tugmalar sifatida ko'rsatish (chap/o'ng)"""
    uc_list = db.get_uc_list()
    if not uc_list:
        return InlineKeyboardMarkup([[InlineKeyboardButton("❌ UC narxlari yo'q", callback_data="none")]])

    items_per_page = 4
    total_pages = (len(uc_list) + items_per_page - 1) // items_per_page
    start = page * items_per_page
    end = start + items_per_page
    current_items = uc_list[start:end]

    rows = []
    for i in range(0, len(current_items), 2):
        row = []
        for item in current_items[i:i+2]:
            row.append(InlineKeyboardButton(
                f"💎 {item['amount']} UC — {item['price']:,} so'm",
                callback_data=f"uc_{item['id']}"
            ))
        rows.append(row)

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton("⬅️ Oldingi", callback_data=f"ucpage_{page-1}"))
    if page < total_pages - 1:
        nav.append(InlineKeyboardButton("Keyingi ➡️", callback_data=f"ucpage_{page+1}"))
    if nav:
        rows.append(nav)

    rows.append([InlineKeyboardButton("❌ Bekor qilish", callback_data="cancel")])
    return InlineKeyboardMarkup(rows)


# ═══════════════════════════════════════════════
#  /start
# ═══════════════════════════════════════════════

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.add_user(user.id, user.username or "", user.full_name or "")

    text = (
        f"👋 Assalomu alaykum, <b>{user.full_name}</b>!\n\n"
        "🎮 <b>PUBG MOBILE UC</b> sotib olish botiga xush kelibsiz!\n\n"
        "Quyidagi menyudan foydalaning:"
    )
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=main_menu_keyboard())


# ═══════════════════════════════════════════════
#  PUBG UC OLISH — 1-QADAM: UC tanlash
# ═══════════════════════════════════════════════

async def pubg_uc_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uc_list = db.get_uc_list()
    if not uc_list:
        await update.message.reply_text(
            "⚠️ Hozircha UC narxlari kiritilmagan. Keyinroq urinib ko'ring.",
            reply_markup=main_menu_keyboard()
        )
        return ConversationHandler.END

    text = (
        "💎 <b>UC miqdorini tanlang:</b>\n\n"
        "⬇️ Quyidagi tugmalardan birini bosing:"
    )
    await update.message.reply_text(
        text,
        parse_mode="HTML",
        reply_markup=uc_list_keyboard(0)
    )
    return UC_SELECT


async def uc_page_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    page = int(query.data.split("_")[1])
    await query.edit_message_reply_markup(reply_markup=uc_list_keyboard(page))
    return UC_SELECT


async def uc_selected(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "cancel":
        await query.edit_message_text("❌ Bekor qilindi.")
        await query.message.reply_text("Asosiy menyu:", reply_markup=main_menu_keyboard())
        return ConversationHandler.END

    uc_id = int(query.data.split("_")[1])
    uc = db.get_uc_by_id(uc_id)
    if not uc:
        await query.edit_message_text("⚠️ Xatolik. Qaytadan urinib ko'ring.")
        return ConversationHandler.END

    context.user_data["selected_uc"] = uc

    await query.edit_message_text(
        f"✅ Tanlandi: <b>{uc['amount']} UC</b> — <b>{uc['price']:,} so'm</b>\n\n"
        f"📸 Endi <b>PUBG ID</b> va <b>nikneymingiz ko'rsatilgan</b> ekran rasmini yuboring:\n"
        f"<i>(PUBG Mobile → Profil → ID raqami ko'rinib tursin)</i>",
        parse_mode="HTML"
    )
    return PUBG_ID_PHOTO


# ═══════════════════════════════════════════════
#  2-QADAM: PUBG ID rasmi
# ═══════════════════════════════════════════════

async def pubg_id_photo_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.photo:
        await update.message.reply_text("⚠️ Iltimos, <b>rasm</b> yuboring!", parse_mode="HTML")
        return PUBG_ID_PHOTO

    photo = update.message.photo[-1]
    context.user_data["pubg_photo_id"] = photo.file_id

    uc = context.user_data["selected_uc"]
    card = db.get_card()

    if not card:
        await update.message.reply_text(
            "⚠️ Hozircha to'lov kartasi sozlanmagan. Admin bilan bog'laning: /yordam",
            reply_markup=main_menu_keyboard()
        )
        return ConversationHandler.END

    text = (
        f"💳 <b>To'lov ma'lumotlari:</b>\n\n"
        f"🔢 Karta raqami:\n<code>{card['number']}</code>\n"
        f"👤 Egasi: <b>{card['owner']}</b>\n"
        f"💰 Summa: <b>{uc['price']:,} so'm</b>\n\n"
        f"✅ To'lovni amalga oshirib, <b>chek (screenshot)</b> rasmini yuboring:"
    )
    await update.message.reply_text(text, parse_mode="HTML")
    return CHECK_PHOTO


# ═══════════════════════════════════════════════
#  3-QADAM: Chek rasmi → adminga xabar
# ═══════════════════════════════════════════════

async def check_photo_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message.photo:
        await update.message.reply_text("⚠️ Iltimos, <b>chek rasmini</b> yuboring!", parse_mode="HTML")
        return CHECK_PHOTO

    user = update.effective_user
    uc = context.user_data["selected_uc"]
    pubg_photo = context.user_data["pubg_photo_id"]
    check_photo = update.message.photo[-1].file_id
    now = tashkent_now()

    order_id = db.create_order(
        user_id=user.id,
        uc_id=uc["id"],
        uc_amount=uc["amount"],
        price=uc["price"],
        pubg_photo=pubg_photo,
        check_photo=check_photo,
        created_at=now,
    )

    # Foydalanuvchiga tasdiqlash
    await update.message.reply_text(
        f"✅ <b>Buyurtmangiz qabul qilindi!</b>\n\n"
        f"🆔 Buyurtma №: <b>{order_id}</b>\n"
        f"💎 UC: <b>{uc['amount']} UC</b>\n"
        f"💰 Summa: <b>{uc['price']:,} so'm</b>\n"
        f"🕐 Vaqt: <b>{now}</b>\n\n"
        f"⏳ Admin tekshirib, tez orada UC yuboriladi.",
        parse_mode="HTML",
        reply_markup=main_menu_keyboard()
    )

    # Adminga xabar
    admin_text = (
        f"🔔 <b>YANGI BUYURTMA #{order_id}</b>\n\n"
        f"👤 Foydalanuvchi: <a href='tg://user?id={user.id}'>{user.full_name}</a>\n"
        f"🆔 Telegram ID: <code>{user.id}</code>\n"
        f"💎 UC miqdori: <b>{uc['amount']} UC</b>\n"
        f"💰 Summa: <b>{uc['price']:,} so'm</b>\n"
        f"🕐 Vaqt (Toshkent): <b>{now}</b>"
    )

    approve_reject = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ Tasdiqlash", callback_data=f"approve_{order_id}"),
            InlineKeyboardButton("❌ Rad etish", callback_data=f"reject_{order_id}"),
        ]
    ])

    for admin_id in ADMIN_IDS:
        try:
            # PUBG ID rasmi
            await context.bot.send_photo(
                chat_id=admin_id,
                photo=pubg_photo,
                caption=f"📸 PUBG ID rasmi — Buyurtma #{order_id}"
            )
            # Chek rasmi + ma'lumotlar
            await context.bot.send_photo(
                chat_id=admin_id,
                photo=check_photo,
                caption=admin_text,
                parse_mode="HTML",
                reply_markup=approve_reject
            )
        except Exception as e:
            logger.error(f"Admin {admin_id} ga xabar yuborishda xato: {e}")

    return ConversationHandler.END


# ═══════════════════════════════════════════════
#  ADMIN — tasdiqlash / rad etish
# ═══════════════════════════════════════════════

async def admin_approve_reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id not in ADMIN_IDS:
        await query.answer("⛔ Ruxsat yo'q!", show_alert=True)
        return

    action, order_id = query.data.split("_", 1)
    order_id = int(order_id)
    order = db.get_order(order_id)

    if not order:
        await query.edit_message_caption("⚠️ Buyurtma topilmadi.", parse_mode="HTML")
        return

    if action == "approve":
        db.update_order_status(order_id, "approved")
        status_text = "✅ <b>TASDIQLANDI</b>"
        user_msg = (
            f"🎉 <b>Buyurtmangiz tasdiqlandi!</b>\n\n"
            f"🆔 Buyurtma №: <b>{order_id}</b>\n"
            f"💎 <b>{order['uc_amount']} UC</b> tez orada yuboriladi.\n"
            f"Rahmat! 🙏"
        )
    else:
        db.update_order_status(order_id, "rejected")
        status_text = "❌ <b>RAD ETILDI</b>"
        user_msg = (
            f"😔 <b>Buyurtmangiz rad etildi.</b>\n\n"
            f"🆔 Buyurtma №: <b>{order_id}</b>\n"
            f"Muammo bo'lsa admin bilan bog'laning."
        )

    now = tashkent_now()
    await query.edit_message_caption(
        query.message.caption + f"\n\n{status_text}\n🕐 {now}",
        parse_mode="HTML"
    )

    try:
        await context.bot.send_message(
            chat_id=order["user_id"],
            text=user_msg,
            parse_mode="HTML"
        )
    except Exception as e:
        logger.error(f"Foydalanuvchiga xabar yuborishda xato: {e}")


# ═══════════════════════════════════════════════
#  ADMIN PANEL
# ═══════════════════════════════════════════════

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ Ruxsat yo'q!")
        return

    await update.message.reply_text(
        "🛠 <b>Admin Panel</b>\n\nQuyidagi menyudan tanlang:",
        parse_mode="HTML",
        reply_markup=admin_menu_keyboard()
    )


# ── UC narxlarini ko'rish ──

async def admin_uc_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return

    uc_list = db.get_uc_list()
    if not uc_list:
        text = "💰 <b>UC narxlari</b>\n\nHali narx kiritilmagan."
    else:
        lines = ["💰 <b>UC narxlari:</b>\n"]
        for i, item in enumerate(uc_list, 1):
            lines.append(f"{i}. 💎 <b>{item['amount']} UC</b> — {item['price']:,} so'm  [ID: {item['id']}]")
        text = "\n".join(lines)

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Yangi UC narxi qo'shish", callback_data="admin_add_uc")],
        [InlineKeyboardButton("🗑 UC narxini o'chirish", callback_data="admin_del_uc_menu")],
    ])
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=kb)


# ── UC qo'shish conversation ──

async def admin_add_uc_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.message.reply_text("💎 UC miqdorini kiriting (masalan: <b>60</b>):", parse_mode="HTML")
    return ADMIN_ADD_UC_AMOUNT


async def admin_add_uc_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    if not text.isdigit():
        await update.message.reply_text("⚠️ Faqat raqam kiriting!")
        return ADMIN_ADD_UC_AMOUNT
    context.user_data["new_uc_amount"] = int(text)
    await update.message.reply_text(f"💰 {text} UC narxini so'mda kiriting (masalan: <b>15000</b>):", parse_mode="HTML")
    return ADMIN_ADD_UC_PRICE


async def admin_add_uc_price(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip().replace(" ", "").replace(",", "")
    if not text.isdigit():
        await update.message.reply_text("⚠️ Faqat raqam kiriting!")
        return ADMIN_ADD_UC_PRICE

    amount = context.user_data["new_uc_amount"]
    price = int(text)
    db.add_uc(amount, price)

    await update.message.reply_text(
        f"✅ <b>{amount} UC — {price:,} so'm</b> muvaffaqiyatli qo'shildi!",
        parse_mode="HTML",
        reply_markup=admin_menu_keyboard()
    )
    return ConversationHandler.END


# ── UC o'chirish ──

async def admin_del_uc_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    uc_list = db.get_uc_list()
    if not uc_list:
        await query.message.reply_text("❌ O'chiriladigan UC yo'q.")
        return

    buttons = []
    for item in uc_list:
        buttons.append([InlineKeyboardButton(
            f"🗑 {item['amount']} UC ({item['price']:,} so'm)",
            callback_data=f"deluc_{item['id']}"
        )])
    buttons.append([InlineKeyboardButton("❌ Bekor qilish", callback_data="cancel_admin")])
    await query.message.reply_text(
        "O'chirmoqchi bo'lgan UC ni tanlang:",
        reply_markup=InlineKeyboardMarkup(buttons)
    )


async def admin_del_uc_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    uc_id = int(query.data.split("_")[1])
    db.delete_uc(uc_id)
    await query.edit_message_text("✅ UC narxi o'chirildi.")


# ── Karta raqamini sozlash ──

async def admin_card_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return

    card = db.get_card()
    if card:
        text = f"💳 <b>Joriy karta:</b>\n<code>{card['number']}</code>\nEgasi: <b>{card['owner']}</b>"
    else:
        text = "💳 Hali karta kiritilmagan."

    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("✏️ Kartani yangilash", callback_data="admin_set_card")]
    ])
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=kb)


async def admin_set_card_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.message.reply_text(
        "💳 Karta raqamini kiriting (masalan: <code>8600 0000 0000 0000</code>):",
        parse_mode="HTML"
    )
    return ADMIN_ADD_CARD


async def admin_set_card_done(update: Update, context: ContextTypes.DEFAULT_TYPE):
    parts = update.message.text.strip().split("\n")
    card_number = parts[0].strip()
    owner = parts[1].strip() if len(parts) > 1 else "Ism Familiya"

    db.set_card(card_number, owner)
    await update.message.reply_text(
        f"✅ Karta saqlandi!\n<code>{card_number}</code>\nEgasi: <b>{owner}</b>",
        parse_mode="HTML",
        reply_markup=admin_menu_keyboard()
    )
    return ConversationHandler.END


# ── Buyurtmalar ──

async def admin_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return

    orders = db.get_recent_orders(10)
    if not orders:
        await update.message.reply_text("📦 Hali buyurtmalar yo'q.")
        return

    lines = ["📦 <b>So'nggi buyurtmalar:</b>\n"]
    for o in orders:
        status_icon = "✅" if o["status"] == "approved" else ("❌" if o["status"] == "rejected" else "⏳")
        lines.append(
            f"{status_icon} #{o['id']} | 💎{o['uc_amount']} UC | {o['price']:,} so'm\n"
            f"   👤 ID: {o['user_id']} | 🕐 {o['created_at']}\n"
        )
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


# ── Statistika ──

async def admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id not in ADMIN_IDS:
        return

    stats = db.get_stats()
    text = (
        f"📊 <b>Statistika:</b>\n\n"
        f"👥 Jami foydalanuvchilar: <b>{stats['users']}</b>\n"
        f"📦 Jami buyurtmalar: <b>{stats['total_orders']}</b>\n"
        f"✅ Tasdiqlangan: <b>{stats['approved']}</b>\n"
        f"❌ Rad etilgan: <b>{stats['rejected']}</b>\n"
        f"⏳ Kutilayotgan: <b>{stats['pending']}</b>\n"
        f"💰 Jami summa (tasdiqlangan): <b>{stats['total_sum']:,} so'm</b>"
    )
    await update.message.reply_text(text, parse_mode="HTML")


# ── Mening buyurtmalarim ──

async def my_orders(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    orders = db.get_user_orders(user_id, limit=5)

    if not orders:
        await update.message.reply_text("📋 Sizda hali buyurtmalar yo'q.")
        return

    lines = ["📋 <b>Sizning buyurtmalaringiz:</b>\n"]
    for o in orders:
        status_icon = "✅" if o["status"] == "approved" else ("❌" if o["status"] == "rejected" else "⏳")
        status_text = "Tasdiqlangan" if o["status"] == "approved" else ("Rad etildi" if o["status"] == "rejected" else "Kutilmoqda")
        lines.append(
            f"{status_icon} #{o['id']} — 💎 <b>{o['uc_amount']} UC</b>\n"
            f"   {status_text} | 🕐 {o['created_at']}\n"
        )
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


# ── Yordam ──

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "🆘 <b>Yordam</b>\n\n"
        "Bot orqali PUBG Mobile UC sotib olasiz:\n\n"
        "1️⃣ <b>PUBG MOBILE UC OLISH</b> tugmasini bosing\n"
        "2️⃣ UC miqdorini tanlang\n"
        "3️⃣ PUBG ID rasmini yuboring\n"
        "4️⃣ Ko'rsatilgan kartaga to'lov qiling\n"
        "5️⃣ Chek rasmini yuboring\n\n"
        "❓ Muammo bo'lsa: @admin_username"
    )
    await update.message.reply_text(text, parse_mode="HTML", reply_markup=main_menu_keyboard())


async def cancel_admin_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await query.edit_message_text("❌ Bekor qilindi.")


# ═══════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════

def main():
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    # UC sotib olish conversation
    uc_conv = ConversationHandler(
        entry_points=[MessageHandler(filters.Regex("^🎮 PUBG MOBILE UC OLISH$"), pubg_uc_start)],
        states={
            UC_SELECT: [
                CallbackQueryHandler(uc_page_callback, pattern="^ucpage_"),
                CallbackQueryHandler(uc_selected, pattern="^(uc_|cancel)"),
            ],
            PUBG_ID_PHOTO: [MessageHandler(filters.PHOTO | filters.TEXT, pubg_id_photo_received)],
            CHECK_PHOTO: [MessageHandler(filters.PHOTO | filters.TEXT, check_photo_received)],
        },
        fallbacks=[CommandHandler("start", start)],
        allow_reentry=True,
    )

    # Admin UC qo'shish conversation
    admin_add_uc_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_add_uc_start, pattern="^admin_add_uc$")],
        states={
            ADMIN_ADD_UC_AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_add_uc_amount)],
            ADMIN_ADD_UC_PRICE: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_add_uc_price)],
        },
        fallbacks=[CommandHandler("start", start)],
    )

    # Admin karta qo'shish conversation
    admin_card_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(admin_set_card_start, pattern="^admin_set_card$")],
        states={
            ADMIN_ADD_CARD: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_set_card_done)],
        },
        fallbacks=[CommandHandler("start", start)],
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(uc_conv)
    app.add_handler(admin_add_uc_conv)
    app.add_handler(admin_card_conv)

    app.add_handler(MessageHandler(filters.Regex("^💰 UC narxlarini boshqarish$"), admin_uc_list))
    app.add_handler(MessageHandler(filters.Regex("^💳 Karta raqamini sozlash$"), admin_card_menu))
    app.add_handler(MessageHandler(filters.Regex("^📦 Buyurtmalar$"), admin_orders))
    app.add_handler(MessageHandler(filters.Regex("^📊 Statistika$"), admin_stats))
    app.add_handler(MessageHandler(filters.Regex("^📋 Mening buyurtmalarim$"), my_orders))
    app.add_handler(MessageHandler(filters.Regex("^🆘 Yordam$"), help_cmd))
    app.add_handler(MessageHandler(filters.Regex("^🔙 Asosiy menyu$"), start))

    app.add_handler(CallbackQueryHandler(admin_approve_reject, pattern="^(approve|reject)_"))
    app.add_handler(CallbackQueryHandler(admin_del_uc_menu, pattern="^admin_del_uc_menu$"))
    app.add_handler(CallbackQueryHandler(admin_del_uc_confirm, pattern="^deluc_"))
    app.add_handler(CallbackQueryHandler(cancel_admin_cb, pattern="^cancel_admin$"))

    logger.info("🤖 Bot ishga tushdi...")
    app.run_polling()


if __name__ == "__main__":
    main()
